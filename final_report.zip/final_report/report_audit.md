# Report Audit — Secure AI Pipeline for Sensitive Data

Author: Rajput Dhirajsing Rajeshsing (2024DA04378)
Report file: `final_report/final_report.pdf`

## 1. Guideline compliance checklist (BITS WILP Guidelines, 06 April 2022)

| Guideline element | Report location | Status |
|---|---|---|
| Cover (Appendix-A specimen) | Front matter, page i | Present |
| Title page (Appendix-B specimen) | Front matter | Present |
| Certificate from Supervisor (Checklist item 4) | Front matter | Present (with signature block) |
| Acknowledgements | Front matter | Present |
| Abstract Sheet (Appendix-C specimen, ≤1 page, keywords, project area) | Front matter | Present, 1 page, keywords + project areas listed |
| Table of Contents (roman for front matter, arabic from Chapter 1) | Front matter | Present |
| List of Figures | Front matter | Present |
| List of Tables | Front matter | Present |
| List of Abbreviations (Checklist item 7) | Front matter | Present, 29 entries |
| Introduction | Chapter 1 (arabic p.1) | Present |
| Literature survey summary (Checklist item 8) | Chapter 2 | Present, 5 sections |
| Main text (methodology, implementation, experiments, results) | Chapters 3–6 | Present |
| Conclusions and Recommendations (item 10) | Chapter 7 | Present, discussion-based |
| References + in-text citations (item 11) | Bibliography + `\cite` calls | Present via BibTeX (unsrt style); every reference is cited |
| Appendices (numbered and titled) | Appendix A–D | Present |
| Glossary | Appendix D | Present |
| Checklist (last page of report) | After Glossary | Present |
| Double-spaced main matter | `\doublespacing` global | Applied |
| ~1" margins | `\usepackage[margin=1in]{geometry}` | Applied |
| Figure captions below figures | `captionsetup[figure]{position=bottom}` | Applied |
| Table captions above tables | `captionsetup[table]{position=top}` | Applied |
| Decimal chapter/section numbering | `report` class with `\thechapter.\arabic{section}` etc. | Applied |
| Chapter 1 begins at arabic page 1 (item 9.i) | `\setcounter{page}{1}` after `\pagenumbering{arabic}` | Applied |
| Report is not a PPT/user-manual printout (item 12) | Full technical prose | Applied |
| Source code not embedded verbatim (item 12) | Only trimmed demo transcript in Appendix C | Applied |
| File size ≤ 10 MB | 1.05 MB | Passed |
| PDF text is machine-readable (Notepad copy-paste test) | LaTeX-generated PDF, all text native | Passed |

## 2. Files inspected

Repository files read or analysed during report preparation:

Guideline / template docs:
- `Guidelines for preparation of WILP Project Report - 06.04.2022.pdf`
- `Checklist of Items for the Final Dissertation, Project, Project Work Report.docx.pdf`
- `main.tex` (mid-semester report, uploaded reference)

Code (from `project_backup/`):
- `module_encryption.py`, `module_deidentification.py`
- `module_midsem_training.py`, `module_dp_training.py`
- `module_inference_api.py`, `module_audit_log.py`, `module_attacks.py`
- `midsem_demo.py`, `train_all_configs.py`, `train_dp_configs.py`
- `demo_sprint3.py`, `run_sprint4_attacks.py`, `plot_pareto_frontier.py`
- `requirements.txt`

Artifacts (from `project_backup/artifacts/`):
- `checkpoints/training_summary.json` — Configs 1, 2 final metrics
- `checkpoints/dp_training_summary.json` — Configs 3, 4 metrics × 3 ε
- `checkpoints/config_1_baseline/metadata.json` and one representative DP metadata
- `midsem_metrics.json` (for context on mid-sem numbers)
- `attack_results.json` — MIA + AIA for all eight configs
- `audit.db` — SQLite chained-hash log (7 events)
- `plots/pareto_frontier.png`
- `plots/epsilon_tradeoffs.png`
- `plots/aia_diagnostics.png`
- `data/diabetic_data.csv` (size only), `data/diabetic_data.csv.enc` (size only), `data/diabetic_data_anonymised.csv` (size only)

## 3. Experiments / results included in the report

- Encryption round-trip on 19,159,383-byte UCI dataset (Chapter 6, Sec. Encryption round-trip in Appendix C)
- De-identification suppression accounting on full 101,766-row dataset (Table 6.1)
- Counter-examples for k-anonymity/l-diversity verifier (Sec 6.1.1)
- Configs 1–4 test-set utility on all eight checkpoints (Table 6.2)
- DP privacy accounting: target vs. spent ε for all six DP checkpoints (Table 6.2)
- MIA (loss/entropy-based) on all eight checkpoints (Table 6.3)
- AIA on race for all eight checkpoints (Table 6.4)
- Privacy-utility Pareto frontier (Fig. 6.3)
- Epsilon trade-off panels: utility + MIA vs. ε (Fig. 6.1)
- AIA diagnostics bar chart (Fig. 6.2)
- Audit log demonstration and tamper detection (Table 6.5)

## 4. Excluded or unusable artifacts

| Item | Reason for exclusion |
|---|---|
| `artifacts_quick/` (entire folder) | Duplicate quick-mode run; superseded by `artifacts/` |
| `artifacts/data/vault.key` | Sensitive material; not reported |
| `artifacts/midsem_metrics.json` | Belongs to the mid-sem report's 12-epoch fixed-schedule run; final report uses the early-stopped checkpoints (`training_summary.json`) that are the models actually served and attacked |
| Raw per-epoch loss series for all 8 configs | Available in each `metadata.json` but not tabulated in the report (would consume ~1 page with limited analytical value); summarised as "best_epoch" and "epochs_run" in Table 6.2 |
| Full source code | Excluded per Guidelines Section 1.2 item 12; only trimmed demo transcript appears (Appendix C) |

## 5. Missing or conflicting information

- **Config 1 / 2 dual numbers.** Two sets of test metrics exist:
  - `training_summary.json` (early-stopped, best_epoch=2): AUC 0.6642 (C1), 0.6651 (C2). **Used in report.**
  - `midsem_metrics.json` (12 fixed epochs): AUC 0.6119 (C1), 0.6192 (C2). Used only in mid-sem report.
  
  The report calls this out explicitly in Section 7.5 ("Reference numbers for Configurations 1 and 2"). The training-summary numbers are used because those checkpoints are the ones the API serves and the attack module attacks.

- **Config 1's `metadata.json` labels `positive_label` as `1` while all other configs label it as `"<30"`.** This is a schema minor version mismatch in the persistence code. It has no effect on numerics: the target binarisation happens before this metadata is written, and all downstream code re-derives the positive label. Noted here for transparency; not repeated in the body of the report.

- **`train_loss_by_epoch` for Config 1 in `metadata.json` has 5 entries** matching `epochs_run=5`, confirming early stopping fired. `midsem_metrics.json` has 12 entries — different run.

- **No conflicting information found** in the other files.

## 6. Unresolved TODOs

None. Every claim in the report is anchored to an artifact file per
`evidence_map.md`. No placeholder text remains in the compiled PDF.

Items intentionally deferred to Future Work (Section 7.3), not TODOs
in the report itself:
1. Adaptive privacy-budget allocation.
2. PATE and Federated Learning + DP comparisons.
3. Shokri-style shadow-model MIA and LiRA-style calibrated attacks.
4. Model inversion / confidence leakage.
5. DP threshold recalibration.
6. External anchoring of the audit head hash.
7. Rate-limiting and query-budget controls on the API.

## 7. LaTeX compilation status

Command sequence (from a clean state):

```
cd final_report/
pdflatex -interaction=nonstopmode main.tex
bibtex   main
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex
cp main.pdf final_report.pdf
```

Results after third `pdflatex` pass:
- **Fatal errors:** 0
- **`!` LaTeX errors in `main.log`:** 0
- **Undefined references / citations warnings:** 0
- **Missing figure warnings:** 0
- **Output file:** `main.pdf` (55 pages, 1,098,504 bytes ≈ 1.05 MB, A4)
- **Renamed deliverable:** `final_report.pdf`

Cosmetic residual warnings (do not affect correctness):
- A handful of underfull/overfull `\hbox` warnings inside the long
  `tabularx` cells of the evidence-map appendix and inside `verbatim`
  filename strings. These are harmless typography warnings caused by
  narrow columns wrapping filenames like `diabetic_data_anonymised.csv`;
  they do not overflow the printable area of the page.

## 8. Final validation pass

- Clean compilation confirmed by re-running the full three-pass build
  and inspecting the log (`grep '^!' main.log` returns nothing).
- All numerical claims cross-checked against `evidence_map.md` sources
  (six of them re-read here from source JSON files during report drafting).
- Captions above tables, below figures — verified via `captionsetup` and
  visual spot check.
- Cross-references (`\ref`, `\label`) all resolved — no `??` in the PDF.
- Bibliography via BibTeX (`unsrt` style) — every entry cited at least
  once in the body.
- Front matter uses roman page numbering; Chapter 1 begins at arabic
  page 1 — verified via `\pagenumbering{arabic}` reset.
- List of Figures / List of Tables present.
- Abstract fits on a single page.
- Checklist is on the last page of the report.
- PDF filesize < 10 MB (1.05 MB) — passes the BITS submission constraint.
