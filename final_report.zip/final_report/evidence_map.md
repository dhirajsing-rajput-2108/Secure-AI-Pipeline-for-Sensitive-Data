# Evidence Map — Secure AI Pipeline for Sensitive Data

Every quantitative claim in the final report is anchored to a source file
in the repository. This document is the authoritative index.

Legend for source paths (repository root = `project_backup/`):

- `artifacts/` — final artifact set used for the report
- `artifacts_quick/` — quick-mode artifacts (not used for reporting)
- Python modules under repo root — implementation code

## 1. Encryption round-trip

| Claim | Source |
|---|---|
| Plaintext size 19,159,383 bytes | `artifacts/data/diabetic_data.csv` (file size) |
| Ciphertext size 25,545,932 bytes | `artifacts/data/diabetic_data.csv.enc` (file size) |
| Round-trip SHA-256 match | Regenerable via `module_encryption.py`; decrypted output at `artifacts/data/diabetic_data_decrypted.csv` |
| Fernet = AES-128-CBC + HMAC-SHA256 | `module_encryption.py` docstring; `cryptography` library spec |

## 2. De-identification suppression accounting

Source: pipeline output on the full UCI dataset, artefactualised as the
anonymised CSV plus in-code counters.

| Claim | Source |
|---|---|
| 101,766 input rows | `artifacts/data/diabetic_data.csv` line count |
| 101,689 output rows | `artifacts/data/diabetic_data_anonymised.csv` line count |
| 77 rows suppressed | Difference (101,766 − 101,689) |
| 15 rows fail k=5 | `module_deidentification.py::suppress_to_satisfy_k_and_l` counter; captured in mid-sem demo output and re-confirmed by mid-sem `main.tex` (uploaded) |
| 77 rows fail l=3 | Same |
| 15 rows fail both | Same |
| Retention 99.92% | 101,689 / 101,766 |
| 50 equivalence classes | Verifier output |
| Smallest class 36 / largest 18,807 / smallest diversity 3 | Verifier output |

## 3. Model utility metrics (Configs 1 & 2)

Two datapoint sets exist for Configs 1/2:

- `artifacts/checkpoints/training_summary.json` (early-stopped, epochs_run=5, best_epoch=2) — **used in final report**
- `artifacts/midsem_metrics.json` (fixed 12 epochs, no early stopping) — used in mid-sem report only

The report uses the training-summary values because those are the models
served by the API and attacked by the MIA/AIA modules.

| Config | Metric | Value | Source |
|---|---|---|---|
| Config 1 | test_accuracy | 0.5978381919423518 | `artifacts/checkpoints/training_summary.json` (rounded to 0.5978) |
| Config 1 | test_f1 | 0.2620507272508715 | Same (rounded to 0.2621) |
| Config 1 | test_roc_auc | 0.6642090269908911 | Same (rounded to 0.6642) |
| Config 1 | best_epoch | 2 | Same |
| Config 1 | epochs_run | 5 (of 30 planned) | Same |
| Config 2 | test_accuracy | 0.5755867313491543 | Same |
| Config 2 | test_f1 | 0.25977589755316716 | Same |
| Config 2 | test_roc_auc | 0.6651336052276012 | Same |
| Config 2 | best_epoch | 2 | Same |
| Config 2 | epochs_run | 5 (of 30 planned) | Same |

## 4. Model utility metrics (Configs 3 & 4, DP-SGD)

Source: `artifacts/checkpoints/dp_training_summary.json` — six rows,
one per (config, ε) pair.

| Config | ε target | ε spent | test_acc | test_f1 | test_roc_auc | best_epoch |
|---|---|---|---|---|---|---|
| 3 | 1.0 | 0.9916 | 0.8884 | 0.0000 | 0.6381 | 11 |
| 3 | 3.0 | 2.9990 | 0.8884 | 0.0000 | 0.6424 | 11 |
| 3 | 8.0 | 7.9981 | 0.8884 | 0.0000 | 0.6447 | 11 |
| 4 | 1.0 | 0.9202 | 0.8884 | 0.0000 | 0.6515 | 8 |
| 4 | 3.0 | 2.8380 | 0.8884 | 0.0000 | 0.6545 | 8 |
| 4 | 8.0 | 7.5937 | 0.8884 | 0.0000 | 0.6560 | 8 |

Additional per-config sources: `artifacts/checkpoints/config_3_dp_only_eps{1,3,8}/metadata.json`
and `config_4_dp_kanon_eps{1,3,8}/metadata.json` (the "dp" sub-dict inside
each metadata.json).

## 5. MIA attack results

Source: `artifacts/attack_results.json` — key `mia` on each of the eight config slugs.

| Config slug | mia_attack_auc | attack_acc | attack_f1 | loss_thr_acc | n_mem | n_non_mem |
|---|---|---|---|---|---|---|
| config_1_baseline | 0.5062 | 0.8235 | 0.9032 | 0.5022 | 71,236 | 15,265 |
| config_2_k_anon_l_div | 0.5023 | 0.8235 | 0.9032 | 0.5017 | 71,181 | 15,254 |
| config_3_dp_only_eps1 | 0.5017 | 0.8235 | 0.9032 | 0.4995 | 71,236 | 15,265 |
| config_3_dp_only_eps3 | 0.5022 | 0.8235 | 0.9032 | 0.4998 | 71,236 | 15,265 |
| config_3_dp_only_eps8 | 0.5026 | 0.8235 | 0.9032 | 0.4992 | 71,236 | 15,265 |
| config_4_dp_kanon_eps1 | 0.4994 | 0.8235 | 0.9032 | 0.4985 | 71,181 | 15,254 |
| config_4_dp_kanon_eps3 | 0.4993 | 0.8235 | 0.9032 | 0.4988 | 71,181 | 15,254 |
| config_4_dp_kanon_eps8 | 0.4992 | 0.8235 | 0.9032 | 0.4993 | 71,181 | 15,254 |

## 6. AIA attack results (target = race)

Source: `artifacts/attack_results.json` — key `aia` on each of the eight config slugs.

| Config slug | base_acc | base_f1 | attack_acc | attack_f1 | acc_gain | f1_gain |
|---|---|---|---|---|---|---|
| config_1_baseline | 0.7553 | 0.6662 | 0.7559 | 0.6676 | +0.0007 | +0.0014 |
| config_2_k_anon_l_div | 0.7556 | 0.6692 | 0.7564 | 0.6691 | +0.0009 | −0.0001 |
| config_3_dp_only_eps1 | 0.7553 | 0.6662 | 0.7557 | 0.6664 | +0.0004 | +0.0002 |
| config_3_dp_only_eps3 | 0.7553 | 0.6662 | 0.7537 | 0.6646 | −0.0016 | −0.0016 |
| config_3_dp_only_eps8 | 0.7553 | 0.6662 | 0.7552 | 0.6646 | −0.0001 | −0.0016 |
| config_4_dp_kanon_eps1 | 0.7556 | 0.6692 | 0.7553 | 0.6682 | −0.0003 | −0.0010 |
| config_4_dp_kanon_eps3 | 0.7556 | 0.6692 | 0.7553 | 0.6679 | −0.0003 | −0.0013 |
| config_4_dp_kanon_eps8 | 0.7556 | 0.6692 | 0.7556 | 0.6680 | 0.0000 | −0.0013 |

## 7. Figures

| Figure | Source PNG (repo) | Report path |
|---|---|---|
| Pareto Frontier | `artifacts/plots/pareto_frontier.png` | `final_report/figures/pareto_frontier.png` |
| Epsilon trade-offs (utility + MIA) | `artifacts/plots/epsilon_tradeoffs.png` | `final_report/figures/epsilon_tradeoffs.png` |
| AIA diagnostics bar chart | `artifacts/plots/aia_diagnostics.png` | `final_report/figures/aia_diagnostics.png` |

All three figures are regenerable via `plot_pareto_frontier.py` from
`artifacts/checkpoints/*/metadata.json` and `artifacts/attack_results.json`.

## 8. Audit log

Source: `artifacts/audit.db` — SQLite database. Schema
`audit_events(id, ts, actor, role, action, payload_json, prev_hash, this_hash)`.

Persisted events (7 total, from Sprint 3 API demo):

| id | actor | role | action | first hash 10 |
|---|---|---|---|---|
| 1 | system | system | api_startup | a051580a41 |
| 2 | analyst | analyst | predict_TAMPERED | c806de72da |
| 3 | analyst | analyst | predict | 80a6350a74 |
| 4 | admin | admin | login | 202cc1488b |
| 5 | admin | admin | audit_tail | 08390d884c |
| 6 | admin | admin | audit_verify | 3edc83210a (intact=true) |
| 7 | admin | admin | audit_verify | bcc2a6773b (intact=false, n=6 after tamper) |

## 9. Configuration hyperparameters

Source per config: `artifacts/checkpoints/<slug>/metadata.json` (`hyperparameters` and `seed` keys).

Key values (confirmed by inspection of two representative metadata files):

- Configs 1, 2: epochs_planned=30, epochs_run=5 (early-stopped), batch_size=512,
  lr=1e-3, weight_decay=1e-5, early_stopping=true, patience=3, min_delta=1e-4,
  pos_weight=7.9605, seed=42.
- Configs 3, 4: hidden=128, dropout=0.2, epochs_planned=15, epochs_run=15 (C3) or 13 (C4),
  batch_size=512, max_physical_batch_size=64, lr=1e-3, weight_decay=0.0,
  early_stopping=true, patience=5, min_delta=1e-4, pos_weight=7.9605, dp_sgd=true.
- DP: target_delta=1e-5, max_grad_norm=1.0, sample_rate≈0.00719, accountant=rdp.

## 10. Source-code line counts

Source: `wc -l *.py` at repo root.

| File | Lines |
|---|---|
| module_encryption.py | 154 |
| module_deidentification.py | 500 |
| module_midsem_training.py | 709 |
| module_dp_training.py | 810 |
| module_inference_api.py | 614 |
| module_audit_log.py | 558 |
| module_attacks.py | 273 |
| midsem_demo.py | 329 |
| train_all_configs.py | 286 |
| train_dp_configs.py | 342 |
| demo_sprint3.py | 308 |
| run_sprint4_attacks.py | 166 |
| plot_pareto_frontier.py | 327 |
| **Total** | **5,376** |
